package com.microservice.ordermanagement.service;

import com.microservice.ordermanagement.model.Order;

public interface OrderService {

	Object createOrder(Order order);
	
	Order getOrder(String id);

}
