package com.microservice.ordermanagement.service;

import com.microservice.ordermanagement.model.OrderItem;

public interface OrderItemService {

	Object createOrderItem(OrderItem order);

	OrderItem getOrderItem(String code);

}
