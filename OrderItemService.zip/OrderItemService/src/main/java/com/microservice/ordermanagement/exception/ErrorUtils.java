package com.microservice.ordermanagement.exception;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;

public class ErrorUtils {

	public static ApiErrorsView createErrorView(Errors errors) {
		List<ApiError> apiErrors = getApiFieldErrors(errors);
		
		List<ApiError> apiGlobalErrors = errors
				.getGlobalErrors().stream().map(fieldError -> new ApiError(HttpStatus.BAD_REQUEST,
						fieldError.getDefaultMessage(), MDC.get("X-B3-TraceId"), fieldError.getCode(), null))
				.collect(Collectors.toList());
		apiErrors.addAll(apiGlobalErrors);
		ApiErrorsView apiErrorsView = new ApiErrorsView(apiErrors);
		return apiErrorsView;
	}

	public static List<ApiError> getApiFieldErrors(Errors errors) {
		List<ApiError> apiErrors = errors
				.getFieldErrors().stream().map(fieldError -> new ApiError(HttpStatus.BAD_REQUEST,
						fieldError.getDefaultMessage(), MDC.get("X-B3-TraceId"), fieldError.getCode(), null))
				.collect(Collectors.toList());
		return apiErrors;
	}
}
